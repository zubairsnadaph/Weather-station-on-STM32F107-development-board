/*=============== P k t P a r s e r . c ===============*/

/*
BY:	George Cheney
		EECE472 / EECE572 Embedded Real Time Systems
		Electrical and Computer Engineering Dept.
		UMASS Lowell
*/

/*
PURPOSE
This is a dummy Parser Task used to test the serial I/O driver module. In the final version 
it will become the Packet Parser Task.

DEMONSTRATES
Multitasking
Semaphores

CHANGES
03-02-2017  - Created for Spring 2017
*/

#include "PktParser.h"
//#include "Payload.h"

//----- c o n s t a n t    d e f i n i t i o n s -----

#define ParserPrio 6 // Parser task priority

/* Size of the Process task stack */
#define	PARSER_STK_SIZE     256 

#define Length 3                /* length of the preamble set of bytes*/
#define P1Char 0x03             /* first preamble byte*/
#define P2Char 0xEF             /* second preamble byte*/
#define P3Char 0xAF             /* third preamble byte*/
#define stdpktln 8              /* minimum packet length expected*/
#define min 0                   /* expected xor result of all bytes in packet*/

typedef enum {P1, P2, P3, T, D, C} ParserStates;

/*----- g l o b a l s -----*/

// Process Task Control Block
OS_TCB parserTCB;

/* Stack space for Process task stack */
CPU_STK			parserStk[PARSER_STK_SIZE];

//----- f u n c t i o n    p r o t o t y p e s -----
CPU_VOID ParsePkt(CPU_VOID *data);

/*----- C r e a t e P a r s e r T a s k ( ) -----

PURPOSE
Create and initialize the Parser Task.
*/
CPU_VOID CreateParserTask(CPU_VOID)
{
	OS_ERR		osErr;/* -- OS Error code */

	/* Create Parser task. */	
  OSTaskCreate(&parserTCB,
               "Processing Task",
               ParsePkt, 
               NULL,
               ParserPrio,
               &parserStk[0],
               PARSER_STK_SIZE / 10,
               PARSER_STK_SIZE,
               0,
               0,
               0,
               (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
               &osErr);

  assert(osErr == OS_ERR_NONE);
}

CPU_VOID ParsePkt(CPU_VOID *data)                                                       
{
      OS_ERR		osErr;
      static ParserStates parserStates= P1;      // initializing to first state
      CPU_INT16S c;								// variable to get a byte
      CPU_INT08U checksum;						//checksum variable 
      CPU_INT08U pktLength;
            CPU_INT08U i = 0;
	for (;;)
	{
          if (PutBfrClosed(&payloadBfrpair))
          {
              OSSemPend(&openPayloadBfrs, 0, OS_OPT_PEND_BLOCKING, NULL, &osErr);
              assert(osErr==OS_ERR_NONE);
          }
          if (!(PutBfrClosed(&payloadBfrpair)))  
          {
          PktBfr *pktBfr = (PktBfr *) PutBfrAddr(&payloadBfrpair);
            c = GetByte();
              switch(parserStates)
              {
                  case P1:                    //first preamble byte check
                      if(c==P1Char)
                      {
                        parserStates = P2; 
                        checksum = P1Char;
                      }
                      else
                      { 
                        pktBfr->payloadLen=-1;
                        PutBfrClose(&payloadBfrpair);
                        OSSemPost(&closedPayloadBfrs, OS_OPT_POST_1, &osErr);
                        assert(osErr==OS_ERR_NONE); 
                      }
                      break;
                  case P2:                  //second preamble byte check
                      if(c==P2Char)
                      {
                        parserStates = P3; 
                        checksum = checksum ^ c;
                      }
                      else
                      {
                        
                        pktBfr->payloadLen=-2;
                        PutBfrClose(&payloadBfrpair);
                        OSSemPost(&closedPayloadBfrs, OS_OPT_POST_1, &osErr);
                        assert(osErr==OS_ERR_NONE); 
                        parserStates = P1;
                      }
                      break;
                  case P3:                  //third preamble byte check
                      if(c==P3Char)
                      {
                        parserStates = T; 
                        checksum = checksum ^ c;
                      }
                      else
                      {
                        
                        pktBfr->payloadLen=-3;
                        PutBfrClose(&payloadBfrpair);
                        OSSemPost(&closedPayloadBfrs, OS_OPT_POST_1, &osErr);
                        assert(osErr==OS_ERR_NONE); 
                        parserStates = P1;
                      }
                      break;
                  case T:                  //length check
                      pktLength=c;
                      if(c>=stdpktln)
                      {
                        pktBfr->payloadLen=pktLength;
                        checksum = checksum ^ c;
                        parserStates = D;
                        i=0;
                      }
                      else
                      {
                        
                        pktBfr->payloadLen=-5;
                        PutBfrClose(&payloadBfrpair);
                        OSSemPost(&closedPayloadBfrs, OS_OPT_POST_1, &osErr);
                        assert(osErr==OS_ERR_NONE); 
                        parserStates = P1;
                      }
                      break;
                    case D:                  //data bytes
                        pktBfr->data[i]=c;
                        checksum = checksum ^ c;
                        i++;
                        if(i==pktLength-5)                                                          
                        {
                              parserStates = C;                         
                        }
                        break;
                    case C:                             //Checksum error check
                        checksum = checksum ^ c;
                        if (checksum == min)
                        {
                            parserStates = P1;
                            PutBfrClose(&payloadBfrpair);
                            OSSemPost(&closedPayloadBfrs, OS_OPT_POST_1, &osErr);
                            assert(osErr==OS_ERR_NONE); 
                        }
                        else
                        { 
                          pktBfr->payloadLen=-4;
                            PutBfrClose(&payloadBfrpair);
                            OSSemPost(&closedPayloadBfrs, OS_OPT_POST_1, &osErr);
                            assert(osErr==OS_ERR_NONE); 
                            parserStates = P1;
                        }
                      break;
              }
              }
      }
}