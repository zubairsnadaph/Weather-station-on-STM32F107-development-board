/*-----------------------Payload.c-------------------------*/
#include "Payload.h"

#define Payload_STK_SIZE 256
#define payloadPRI 6
#define Idsize 10              //size of id array
#define low 0                  //index # for first element of speed array
#define msg1 1                 // intializing the value to 1 corresponding to packet message #
#define msg2 2                 // intializing the value to 2 corresponding to packet message #
#define msg3 3                 // intializing the value to 3 corresponding to packet message #
#define bitMask8 0xFF          // masking byte
#define bitMask5 0x1F          // masking byte
#define bitMask4 0x0F          // masking byte
#define bitMask24 0xFF0000     // masking byte
#define bitMask16 0xFF00       // masking byte
#define bitMask32 0xFF000000   // masking byte
#define times8 8               // to shift the variable by 8 times
#define times4 4               // to shift the variable by 4 times
#define times5 5               // to shift the variable by 5 times
#define times24 24             // to shift the variable by 24 times
#define times27 27             // to shift the variable by 27 times
#define times16 16             // to shift the variable by 16 times
#define times21 21             // to shift the variable by 21 times
#define times9 9               // to shift the variable by 9 times
#define Hour 0x07E00000        // masking byte to display minutes
#define year 0xFFF             // masking byte to display year
#define stdmsgType 8           // predefined to check the message type error

typedef struct
{
    CPU_INT08S payloadLen;      
    CPU_INT08U dstAddr;
    CPU_INT08U srcAddr;
    CPU_INT08U msgType;
    union
      {
        CPU_INT08S temp;
        CPU_INT16U press;
        struct
        {
            CPU_INT08S dew;
            CPU_INT08U hum;
        }Humidity;
        struct
        {
            CPU_INT08U speed[msg2];
            CPU_INT16U direct;
        }Windmsg;
        CPU_INT16U Intensity;
        CPU_INT32U TimeDate;
        CPU_INT08U Depth[msg2];
        CPU_INT08U Id[Idsize];
      }DataPart;
}PayLoad;	//Payload data type 

enum {mssg1=1, mssg2, mssg3, mssg4, mssg5, mssg6, mssg7, mssg8} mssgtype;

static OS_TCB payloadTCB;
static CPU_STK PayloadSTK[Payload_STK_SIZE];
BfrPair payloadBfrpair;

#ifndef MaxPayload 
#define MayPayload 14
#endif

CPU_INT08U payload0Space[MaxPayload];
CPU_INT08U payload1Space[MaxPayload];

OS_SEM openPayloadBfrs;
OS_SEM closedPayloadBfrs;

CPU_VOID Payload(CPU_VOID *data);
CPU_VOID errors(CPU_INT16S error);

CPU_VOID CreatePayloadTask(CPU_VOID)
{
	OS_ERR		osErr;/* -- OS Error code */

	/* Create Parser task. */	
  OSTaskCreate(&payloadTCB,
               "AnalysingPkt Task",
               Payload, 
               NULL,
               payloadPRI,
               &PayloadSTK[0],
               Payload_STK_SIZE / 10,
               Payload_STK_SIZE,
               0,
               0,
               0,
               (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
               &osErr);

  assert(osErr == OS_ERR_NONE);
  
  OSSemCreate(&openPayloadBfrs, "OPEN Payload Buffers", 2, &osErr);			/* -- Empty at start. */
  assert(osErr == OS_ERR_NONE);
  
  OSSemCreate(&closedPayloadBfrs, "CLOSED Payload Bfrs", 0, &osErr);	                /* -- BfrSize bytes available. */
  assert(osErr == OS_ERR_NONE);
}

CPU_VOID Payload(CPU_VOID *data)
{
    OS_ERR		osErr;
    PayLoad *payloadbfr;
    BfrPairInit(&payloadBfrpair, payload0Space, payload1Space, MaxPayload);
    for(;;)
    {   
        if (!GetBfrClosed(&payloadBfrpair))
        {
            OSSemPend(&closedPayloadBfrs, 0, OS_OPT_PEND_BLOCKING, NULL, &osErr);
            assert(osErr==OS_ERR_NONE);
            if(BfrPairSwappable(&payloadBfrpair))
              {
                  BfrPairSwap(&payloadBfrpair);
              }
        }   
         payloadbfr = (PayLoad *) GetBfrAddr(&payloadBfrpair);
         if (GetBfrClosed(&payloadBfrpair))
         {
          if (payloadbfr->payloadLen < 0)
              errors(payloadbfr->payloadLen); 
          else
          { 
           if(payloadbfr->dstAddr==1)
                
            {
                CPU_INT32U datetime; // datatype to convert the date/time in proper order of byte arrangement
                switch(payloadbfr->msgType)
                {
                case 1:
                  SerPrintf("SOURCE NODE = %d \tTEMPERATURE MESSAGE \n TEMPERATURE= %d \n", payloadbfr->srcAddr, payloadbfr->DataPart.temp);
                  break;
                case 2:
                  SerPrintf("SOURCE NODE = %d \tBAROMETRIC MESSAGE \n PRESSURE= %d \n", payloadbfr->srcAddr, 
                                  ((payloadbfr->DataPart.press & bitMask8)<< times8) | ((payloadbfr->DataPart.press >> times8)& bitMask8));
                  break;
                case 3:
                  SerPrintf("SOURCE NODE = %d \tHUMIDITY MESSAGE \n DEW POINT= %d \t HUMIDITY= %d\n", 
                                  payloadbfr->srcAddr, payloadbfr->DataPart.Humidity.dew, payloadbfr->DataPart.Humidity.hum);
                  break;
                case 4:
                  SerPrintf("SOURCE NODE = %d \tWIND MESSAGE \n WIND SPEED=%d%d%d.%d \t WIND DIRECTION=%d\n", 
                                  payloadbfr->srcAddr, ((payloadbfr->DataPart.Windmsg.speed[low]>> times4) & bitMask4), 
                                  (payloadbfr->DataPart.Windmsg.speed[low]& bitMask4), ((payloadbfr->DataPart.Windmsg.speed[msg1]>> times4)& bitMask4),
                                  (payloadbfr->DataPart.Windmsg.speed[msg1]& bitMask4),((payloadbfr->DataPart.Windmsg.direct>>times8)& bitMask8)|((payloadbfr->DataPart.Windmsg.direct & bitMask8)<< times8)) ;
                  break;
                case 5:
                  SerPrintf("SOURCE NODE = %d \tSOLAR MESSAGE \n RADIATION=%d \n", payloadbfr->srcAddr, 
                                 ((payloadbfr->DataPart.Intensity>>times8)& bitMask8)|((payloadbfr->DataPart.Intensity & bitMask8)<<times8));
                  break;
                case 6:
                  datetime= ((payloadbfr->DataPart.TimeDate & bitMask8)<<times24)|((payloadbfr->DataPart.TimeDate & bitMask16)<<times8)|((payloadbfr->DataPart.TimeDate & bitMask24)>>times8)|((payloadbfr->DataPart.TimeDate & bitMask32)>>times24);
                  SerPrintf("SOURCE NODE = %d \tDATE/TIME MESSAGE \n DATE/TIME=%d/%d/%d  %d:%d\n", payloadbfr->srcAddr,
                                 ((datetime>>times5)&bitMask4),(datetime & bitMask5),((datetime>>times9)& year),((datetime>>times27)& bitMask5),((datetime & Hour)>>times21));
                  break;
                case 7:
                  SerPrintf("SOURCE NODE = %d \tPRECIPITATION MESSAGE \n PRECIPITATION DEPTH=%d%d.%d%d \n", payloadbfr->srcAddr, 
                                 ((payloadbfr->DataPart.Depth[low]>> times4) & bitMask4), (payloadbfr->DataPart.Depth[low]& bitMask4), 
                                 ((payloadbfr->DataPart.Depth[msg1]>> times4)& bitMask4),(payloadbfr->DataPart.Depth[msg1]& bitMask4));
                  break;
                case 8:
                  SerPrintf("SOURCE NODE = %d \tNODE MESSAGE \n NODE= %c\n", payloadbfr->srcAddr, payloadbfr->DataPart.Id[5]);
                  break;
                default :   
                  SerPrintf("\n\a ***Incorrect Message Type\n");
                  break;
                }
               
            }
        
               
         else
            SerPrintf("\n\a ***directed to some other device\n");
        
    }
                GetBfrOpen(&payloadBfrpair);
                OSSemPost(&openPayloadBfrs, OS_OPT_POST_1, &osErr);
                assert(osErr==OS_ERR_NONE);       
        }}
}
/*function errors() prints the respective error on COMAPP*/ 
CPU_VOID errors(CPU_INT16S error)
{
OS_ERR osErr;
switch (error)
        {

        case -1:
          SerPrintf("\n\a ***Preamble 1 error\n");
          break;
        case -2:
          SerPrintf("\n\a ***Preamble 2 error\n");
          break;
        case -3:
          SerPrintf("\n\a ***Preamble 3 error\n");
          break;
        case -4:
          SerPrintf("\n\a ***Checksum error\n");
          break;
        case -5:
          SerPrintf("\n\a ***Packet Size error\n");
          break;
        default:
          SerPrintf("\n\a ***No defined  error\n");
          break;
        }
        GetBfrOpen(&payloadBfrpair);            
                OSSemPost(&openPayloadBfrs, OS_OPT_POST_1, &osErr);  //Posts to PktParser.c
                assert(osErr==OS_ERR_NONE); 
}
