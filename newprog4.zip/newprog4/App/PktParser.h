#ifndef PKTPARSER_H
#define PKTPARSER_H

/*=============== P k t P a r s e r . h ===============*/

/*
BY:	George Cheney
		EECE472 / EECE572 Embedded Real Time Systems
		Electrical and Computer Engineering Dept.
		UMASS Lowell
*/

/*
PURPOSE
This is the interface to the module PktParser.c.

CHANGES
03-02-2017  - Created for Spring 2017
*/

#include "includes.h"

#include "BfrPair.h"
#include "SerIODriver.h"
#include "Payload.h"
#include "assert.h"

typedef struct
{
  CPU_INT08S  payloadLen;
  CPU_INT08U  data[1];
}PktBfr; //pkt buffer type 

//----- f u n c t i o n    p r o t o t y p e s -----

CPU_VOID CreateParserTask(CPU_VOID);
#endif