/*------------------------------Payload.h--------------------------*/
#ifndef PAYLOAD_H
#define PAYLOAD_H
#include <stdio.h>
#include <stdlib.h>

#include "includes.h"
#include "SerIODriver.h"
#include "assert.h"
#include "BfrPair.h"

#define MaxPayload 14           //Maximum bytes in a payload
extern BfrPair payloadBfrpair;  //Payload buffer pair defined in Payload.c

//semaphores defined in Payload.c
extern OS_SEM openPayloadBfrs;  //Number of open payload buffers defined in SerIODriver.c
extern OS_SEM closedPayloadBfrs;//Number of closed payload buffers defined in SerIODriver.c 

//call this function to create the payload task.
CPU_VOID CreatePayloadTask(CPU_VOID);
#endif